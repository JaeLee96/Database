Few hours before the submission deadline,
I had finished everything and everything was running fine.
However I was working in terminal and inadvertently made very tiny 
change that I'm not aware of and now pointing browser to localhost:1480
shows 'Internal Server Error'.

I've tried everything, reset, and wrote codes again and it still shows 'Internal Server Error'
I have spent last couple of hours trying to fix the issue but it was all in vain

I looked into ~/www/logs/errlog and /var/log/nginx/errlog
but it kept saying 'no python application found' and I was pulling my hair out
what the source of error is

Failing to find the solution to the bug, I submitted the files that still showed 'Internal Server Error'

/* UPDATE 3:30 AM 5/6/2019 */

I have re-started everything and copy and pasted line by line carefully
and now it works back again


Citation: https://pynative.com/python-postgresql-tutorial/#Python_Example_to_Connect_PostgreSQL_Database
Slip: Using 2 days late pass
